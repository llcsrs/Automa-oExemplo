
# Estrutura base de automação de testes com Behave e Python

## Pré-requisitos:

 - Instalar  [Python 3.5+](https://www.python.org/)
 - Instalar alguma IDE ou editor de texto para desenvolvimento como [PyCharm](https://www.jetbrains.com/pycharm/)
 - Instalar dependências executando na raiz do projeto: `pip install -r requirements.txt`
 
 Tutorial completo: [acesse aqui](https://medium.com/cwi-software/automa%C3%A7%C3%A3o-de-testes-com-python-733c1ff50ff6)

## Execução dos testes:

 - Pelo terminal, executar na raiz do projeto o comando: `behave`
